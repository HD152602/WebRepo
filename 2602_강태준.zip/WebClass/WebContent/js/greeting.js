var a=1;
while(true) {
	alert("안녕하세요?!X"+a);
	a++;
	if(a>10)
		break;
}